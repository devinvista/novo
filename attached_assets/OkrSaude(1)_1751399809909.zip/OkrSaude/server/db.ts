
import sql from 'mssql';
import { drizzle } from 'drizzle-orm/mssql';
import * as schema from "@shared/schema";

if (!process.env.SQL_SERVER_CONNECTION_STRING) {
  throw new Error(
    "SQL_SERVER_CONNECTION_STRING must be set. Did you forget to configure SQL Server?",
  );
}

// Configuração do SQL Server com Azure AD
const config: sql.config = {
  server: 'uxtc4qteojcetnlefqhbolxtcu-rpyxvvjlg7luzcfqp4vnum6pty.database.fabric.microsoft.com',
  port: 1433,
  database: 'OKR-eba598b1-61bc-43d3-b6b6-da74213b7ec6',
  authentication: {
    type: 'azure-active-directory-access-token' as const,
    options: {
      token: process.env.AZURE_AD_TOKEN || ''
    }
  },
  options: {
    encrypt: true,
    trustServerCertificate: false,
    enableArithAbort: true,
    connectTimeout: 30000,
    requestTimeout: 30000
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

export const pool = new sql.ConnectionPool(config);

// Conectar ao pool
pool.connect().then(() => {
  console.log('Conectado ao SQL Server com sucesso');
}).catch(err => {
  console.error('Erro ao conectar ao SQL Server:', err);
});

export const db = drizzle(pool, { schema });
