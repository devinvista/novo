
import { ConfidentialClientApplication } from '@azure/msal-node';

const clientConfig = {
  auth: {
    clientId: process.env.AZURE_CLIENT_ID || '',
    clientSecret: process.env.AZURE_CLIENT_SECRET || '',
    authority: `https://login.microsoftonline.com/${process.env.AZURE_TENANT_ID || 'common'}`,
  },
};

const cca = new ConfidentialClientApplication(clientConfig);

export async function getAccessToken(): Promise<string> {
  const clientCredentialRequest = {
    scopes: ['https://database.windows.net/.default'],
  };

  try {
    const response = await cca.acquireTokenByClientCredential(clientCredentialRequest);
    return response?.accessToken || '';
  } catch (error) {
    console.error('Erro ao obter token do Azure AD:', error);
    throw error;
  }
}

export { cca };
