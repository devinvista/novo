import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertObjectiveSchema,
  insertKeyResultSchema,
  insertActionSchema,
  insertServiceLineSchema,
  insertRegionSchema,
  insertPeriodSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard metrics
  app.get('/api/dashboard/metrics', isAuthenticated, async (req, res) => {
    try {
      const filters = {
        serviceLineId: req.query.serviceLineId ? parseInt(req.query.serviceLineId as string) : undefined,
        periodId: req.query.periodId ? parseInt(req.query.periodId as string) : undefined,
        regionId: req.query.regionId ? parseInt(req.query.regionId as string) : undefined,
      };
      
      const metrics = await storage.getDashboardMetrics(filters);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  // Service Lines
  app.get('/api/service-lines', isAuthenticated, async (req, res) => {
    try {
      const serviceLines = await storage.getServiceLines();
      res.json(serviceLines);
    } catch (error) {
      console.error("Error fetching service lines:", error);
      res.status(500).json({ message: "Failed to fetch service lines" });
    }
  });

  app.post('/api/service-lines', isAuthenticated, async (req, res) => {
    try {
      const data = insertServiceLineSchema.parse(req.body);
      const serviceLine = await storage.createServiceLine(data);
      res.status(201).json(serviceLine);
    } catch (error) {
      console.error("Error creating service line:", error);
      res.status(400).json({ message: "Failed to create service line" });
    }
  });

  // Regions
  app.get('/api/regions', isAuthenticated, async (req, res) => {
    try {
      const regions = await storage.getRegions();
      res.json(regions);
    } catch (error) {
      console.error("Error fetching regions:", error);
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });

  // Periods
  app.get('/api/periods', isAuthenticated, async (req, res) => {
    try {
      const periods = await storage.getPeriods();
      res.json(periods);
    } catch (error) {
      console.error("Error fetching periods:", error);
      res.status(500).json({ message: "Failed to fetch periods" });
    }
  });

  app.get('/api/periods/current', isAuthenticated, async (req, res) => {
    try {
      const period = await storage.getCurrentPeriod();
      res.json(period);
    } catch (error) {
      console.error("Error fetching current period:", error);
      res.status(500).json({ message: "Failed to fetch current period" });
    }
  });

  // Objectives
  app.get('/api/objectives', isAuthenticated, async (req, res) => {
    try {
      const filters = {
        serviceLineId: req.query.serviceLineId ? parseInt(req.query.serviceLineId as string) : undefined,
        periodId: req.query.periodId ? parseInt(req.query.periodId as string) : undefined,
        regionId: req.query.regionId ? parseInt(req.query.regionId as string) : undefined,
        responsibleId: req.query.responsibleId as string,
        status: req.query.status as string,
      };
      
      const objectives = await storage.getObjectives(filters);
      res.json(objectives);
    } catch (error) {
      console.error("Error fetching objectives:", error);
      res.status(500).json({ message: "Failed to fetch objectives" });
    }
  });

  app.get('/api/objectives/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const objective = await storage.getObjectiveById(id);
      if (!objective) {
        return res.status(404).json({ message: "Objective not found" });
      }
      res.json(objective);
    } catch (error) {
      console.error("Error fetching objective:", error);
      res.status(500).json({ message: "Failed to fetch objective" });
    }
  });

  app.post('/api/objectives', isAuthenticated, async (req: any, res) => {
    try {
      const data = insertObjectiveSchema.parse({
        ...req.body,
        createdBy: req.user.claims.sub
      });
      const objective = await storage.createObjective(data);
      res.status(201).json(objective);
    } catch (error) {
      console.error("Error creating objective:", error);
      res.status(400).json({ message: "Failed to create objective" });
    }
  });

  app.put('/api/objectives/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const data = insertObjectiveSchema.partial().parse(req.body);
      const objective = await storage.updateObjective(id, data);
      res.json(objective);
    } catch (error) {
      console.error("Error updating objective:", error);
      res.status(400).json({ message: "Failed to update objective" });
    }
  });

  app.delete('/api/objectives/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteObjective(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting objective:", error);
      res.status(500).json({ message: "Failed to delete objective" });
    }
  });

  // Key Results
  app.get('/api/key-results', isAuthenticated, async (req, res) => {
    try {
      const objectiveId = req.query.objectiveId ? parseInt(req.query.objectiveId as string) : undefined;
      const keyResults = await storage.getKeyResults(objectiveId);
      res.json(keyResults);
    } catch (error) {
      console.error("Error fetching key results:", error);
      res.status(500).json({ message: "Failed to fetch key results" });
    }
  });

  app.get('/api/key-results/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const keyResult = await storage.getKeyResultById(id);
      if (!keyResult) {
        return res.status(404).json({ message: "Key result not found" });
      }
      res.json(keyResult);
    } catch (error) {
      console.error("Error fetching key result:", error);
      res.status(500).json({ message: "Failed to fetch key result" });
    }
  });

  app.post('/api/key-results', isAuthenticated, async (req: any, res) => {
    try {
      const data = insertKeyResultSchema.parse({
        ...req.body,
        createdBy: req.user.claims.sub
      });
      const keyResult = await storage.createKeyResult(data);
      res.status(201).json(keyResult);
    } catch (error) {
      console.error("Error creating key result:", error);
      res.status(400).json({ message: "Failed to create key result" });
    }
  });

  app.put('/api/key-results/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const data = insertKeyResultSchema.partial().parse(req.body);
      const keyResult = await storage.updateKeyResult(id, data);
      res.json(keyResult);
    } catch (error) {
      console.error("Error updating key result:", error);
      res.status(400).json({ message: "Failed to update key result" });
    }
  });

  app.delete('/api/key-results/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteKeyResult(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting key result:", error);
      res.status(500).json({ message: "Failed to delete key result" });
    }
  });

  // Actions
  app.get('/api/actions', isAuthenticated, async (req, res) => {
    try {
      const keyResultId = req.query.keyResultId ? parseInt(req.query.keyResultId as string) : undefined;
      const actions = await storage.getActions(keyResultId);
      res.json(actions);
    } catch (error) {
      console.error("Error fetching actions:", error);
      res.status(500).json({ message: "Failed to fetch actions" });
    }
  });

  app.get('/api/actions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const action = await storage.getActionById(id);
      if (!action) {
        return res.status(404).json({ message: "Action not found" });
      }
      res.json(action);
    } catch (error) {
      console.error("Error fetching action:", error);
      res.status(500).json({ message: "Failed to fetch action" });
    }
  });

  app.post('/api/actions', isAuthenticated, async (req: any, res) => {
    try {
      const data = insertActionSchema.parse({
        ...req.body,
        createdBy: req.user.claims.sub
      });
      const action = await storage.createAction(data);
      res.status(201).json(action);
    } catch (error) {
      console.error("Error creating action:", error);
      res.status(400).json({ message: "Failed to create action" });
    }
  });

  app.put('/api/actions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const data = insertActionSchema.partial().parse(req.body);
      const action = await storage.updateAction(id, data);
      res.json(action);
    } catch (error) {
      console.error("Error updating action:", error);
      res.status(400).json({ message: "Failed to update action" });
    }
  });

  app.delete('/api/actions/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteAction(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting action:", error);
      res.status(500).json({ message: "Failed to delete action" });
    }
  });

  // Checkpoints
  app.get('/api/checkpoints/:keyResultId', isAuthenticated, async (req, res) => {
    try {
      const keyResultId = parseInt(req.params.keyResultId);
      const checkpoints = await storage.getCheckpoints(keyResultId);
      res.json(checkpoints);
    } catch (error) {
      console.error("Error fetching checkpoints:", error);
      res.status(500).json({ message: "Failed to fetch checkpoints" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
