import {
  users,
  serviceLines,
  regions,
  periods,
  objectives,
  keyResults,
  actions,
  checkpoints,
  progressHistory,
  type User,
  type UpsertUser,
  type ServiceLine,
  type Region,
  type Period,
  type Objective,
  type KeyResult,
  type Action,
  type Checkpoint,
  type InsertServiceLine,
  type InsertRegion,
  type InsertPeriod,
  type InsertObjective,
  type InsertKeyResult,
  type InsertAction,
  type InsertCheckpoint,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql, ilike } from "drizzle-orm";

export interface IStorage {
  // User operations - required for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Service Lines
  getServiceLines(): Promise<ServiceLine[]>;
  createServiceLine(data: InsertServiceLine): Promise<ServiceLine>;
  updateServiceLine(id: number, data: Partial<InsertServiceLine>): Promise<ServiceLine>;

  // Regions
  getRegions(): Promise<Region[]>;
  createRegion(data: InsertRegion): Promise<Region>;

  // Periods
  getPeriods(): Promise<Period[]>;
  getCurrentPeriod(): Promise<Period | undefined>;
  createPeriod(data: InsertPeriod): Promise<Period>;

  // Objectives
  getObjectives(filters?: {
    serviceLineId?: number;
    periodId?: number;
    regionId?: number;
    responsibleId?: string;
    status?: string;
  }): Promise<Objective[]>;
  getObjectiveById(id: number): Promise<Objective | undefined>;
  createObjective(data: InsertObjective): Promise<Objective>;
  updateObjective(id: number, data: Partial<InsertObjective>): Promise<Objective>;
  deleteObjective(id: number): Promise<void>;

  // Key Results
  getKeyResults(objectiveId?: number): Promise<KeyResult[]>;
  getKeyResultById(id: number): Promise<KeyResult | undefined>;
  createKeyResult(data: InsertKeyResult): Promise<KeyResult>;
  updateKeyResult(id: number, data: Partial<InsertKeyResult>): Promise<KeyResult>;
  deleteKeyResult(id: number): Promise<void>;

  // Actions
  getActions(keyResultId?: number): Promise<Action[]>;
  getActionById(id: number): Promise<Action | undefined>;
  createAction(data: InsertAction): Promise<Action>;
  updateAction(id: number, data: Partial<InsertAction>): Promise<Action>;
  deleteAction(id: number): Promise<void>;

  // Checkpoints
  getCheckpoints(keyResultId: number): Promise<Checkpoint[]>;
  createCheckpoint(data: InsertCheckpoint): Promise<Checkpoint>;

  // Dashboard metrics
  getDashboardMetrics(filters?: {
    serviceLineId?: number;
    periodId?: number;
    regionId?: number;
  }): Promise<{
    totalObjectives: number;
    totalKeyResults: number;
    totalActions: number;
    averageProgress: number;
    statusDistribution: Record<string, number>;
    progressByServiceLine: Array<{
      serviceLineName: string;
      progress: number;
    }>;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations - required for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Service Lines
  async getServiceLines(): Promise<ServiceLine[]> {
    return await db.select().from(serviceLines).where(eq(serviceLines.active, true)).orderBy(asc(serviceLines.name));
  }

  async createServiceLine(data: InsertServiceLine): Promise<ServiceLine> {
    const [serviceLine] = await db.insert(serviceLines).values(data).returning();
    return serviceLine;
  }

  async updateServiceLine(id: number, data: Partial<InsertServiceLine>): Promise<ServiceLine> {
    const [serviceLine] = await db
      .update(serviceLines)
      .set({ ...data, updatedAt: new Date() } as any)
      .where(eq(serviceLines.id, id))
      .returning();
    return serviceLine;
  }

  // Regions
  async getRegions(): Promise<Region[]> {
    return await db.select().from(regions).where(eq(regions.active, true)).orderBy(asc(regions.name));
  }

  async createRegion(data: InsertRegion): Promise<Region> {
    const [region] = await db.insert(regions).values(data).returning();
    return region;
  }

  // Periods
  async getPeriods(): Promise<Period[]> {
    return await db.select().from(periods).where(eq(periods.active, true)).orderBy(desc(periods.year), desc(periods.quarter));
  }

  async getCurrentPeriod(): Promise<Period | undefined> {
    const [period] = await db
      .select()
      .from(periods)
      .where(
        and(
          eq(periods.active, true),
          sql`${periods.startDate} <= CURRENT_DATE AND ${periods.endDate} >= CURRENT_DATE`
        )
      )
      .limit(1);
    return period;
  }

  async createPeriod(data: InsertPeriod): Promise<Period> {
    const [period] = await db.insert(periods).values(data).returning();
    return period;
  }

  // Objectives
  async getObjectives(filters?: {
    serviceLineId?: number;
    periodId?: number;
    regionId?: number;
    responsibleId?: string;
    status?: string;
  }): Promise<Objective[]> {
    let query = db.select().from(objectives);
    
    const conditions = [];
    if (filters?.serviceLineId) conditions.push(eq(objectives.serviceLineId, filters.serviceLineId));
    if (filters?.periodId) conditions.push(eq(objectives.periodId, filters.periodId));
    if (filters?.regionId) conditions.push(eq(objectives.regionId, filters.regionId));
    if (filters?.responsibleId) conditions.push(eq(objectives.responsibleId, filters.responsibleId));
    if (filters?.status) conditions.push(eq(objectives.status, filters.status));

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    return await query.orderBy(desc(objectives.createdAt));
  }

  async getObjectiveById(id: number): Promise<Objective | undefined> {
    const [objective] = await db.select().from(objectives).where(eq(objectives.id, id));
    return objective;
  }

  async createObjective(data: InsertObjective): Promise<Objective> {
    const [objective] = await db.insert(objectives).values(data).returning();
    return objective;
  }

  async updateObjective(id: number, data: Partial<InsertObjective>): Promise<Objective> {
    const [objective] = await db
      .update(objectives)
      .set({ ...data, updatedAt: new Date() } as any)
      .where(eq(objectives.id, id))
      .returning();
    return objective;
  }

  async deleteObjective(id: number): Promise<void> {
    await db.delete(objectives).where(eq(objectives.id, id));
  }

  // Key Results
  async getKeyResults(objectiveId?: number): Promise<KeyResult[]> {
    let query = db.select().from(keyResults);
    
    if (objectiveId) {
      query = query.where(eq(keyResults.objectiveId, objectiveId));
    }

    return await query.orderBy(desc(keyResults.createdAt));
  }

  async getKeyResultById(id: number): Promise<KeyResult | undefined> {
    const [keyResult] = await db.select().from(keyResults).where(eq(keyResults.id, id));
    return keyResult;
  }

  async createKeyResult(data: InsertKeyResult): Promise<KeyResult> {
    const [keyResult] = await db.insert(keyResults).values(data).returning();
    return keyResult;
  }

  async updateKeyResult(id: number, data: Partial<InsertKeyResult>): Promise<KeyResult> {
    const [keyResult] = await db
      .update(keyResults)
      .set({ ...data, updatedAt: new Date() } as any)
      .where(eq(keyResults.id, id))
      .returning();
    return keyResult;
  }

  async deleteKeyResult(id: number): Promise<void> {
    await db.delete(keyResults).where(eq(keyResults.id, id));
  }

  // Actions
  async getActions(keyResultId?: number): Promise<Action[]> {
    let query = db.select().from(actions);
    
    if (keyResultId) {
      query = query.where(eq(actions.keyResultId, keyResultId));
    }

    return await query.orderBy(desc(actions.createdAt));
  }

  async getActionById(id: number): Promise<Action | undefined> {
    const [action] = await db.select().from(actions).where(eq(actions.id, id));
    return action;
  }

  async createAction(data: InsertAction): Promise<Action> {
    const [action] = await db.insert(actions).values(data).returning();
    return action;
  }

  async updateAction(id: number, data: Partial<InsertAction>): Promise<Action> {
    const [action] = await db
      .update(actions)
      .set({ ...data, updatedAt: new Date() } as any)
      .where(eq(actions.id, id))
      .returning();
    return action;
  }

  async deleteAction(id: number): Promise<void> {
    await db.delete(actions).where(eq(actions.id, id));
  }

  // Checkpoints
  async getCheckpoints(keyResultId: number): Promise<Checkpoint[]> {
    return await db
      .select()
      .from(checkpoints)
      .where(eq(checkpoints.keyResultId, keyResultId))
      .orderBy(desc(checkpoints.date));
  }

  async createCheckpoint(data: InsertCheckpoint): Promise<Checkpoint> {
    const [checkpoint] = await db.insert(checkpoints).values(data).returning();
    return checkpoint;
  }

  // Dashboard metrics
  async getDashboardMetrics(filters?: {
    serviceLineId?: number;
    periodId?: number;
    regionId?: number;
  }): Promise<{
    totalObjectives: number;
    totalKeyResults: number;
    totalActions: number;
    averageProgress: number;
    statusDistribution: Record<string, number>;
    progressByServiceLine: Array<{
      serviceLineName: string;
      progress: number;
    }>;
  }> {
    const conditions = [];
    if (filters?.serviceLineId) conditions.push(eq(objectives.serviceLineId, filters.serviceLineId));
    if (filters?.periodId) conditions.push(eq(objectives.periodId, filters.periodId));
    if (filters?.regionId) conditions.push(eq(objectives.regionId, filters.regionId));

    // Total objectives
    let objectivesQuery = db.select({ count: sql<number>`count(*)` }).from(objectives);
    if (conditions.length > 0) {
      objectivesQuery = objectivesQuery.where(and(...conditions));
    }
    const [{ count: totalObjectives }] = await objectivesQuery;

    // Total key results
    let keyResultsQuery = db
      .select({ count: sql<number>`count(*)` })
      .from(keyResults)
      .innerJoin(objectives, eq(keyResults.objectiveId, objectives.id));
    if (conditions.length > 0) {
      keyResultsQuery = keyResultsQuery.where(and(...conditions));
    }
    const [{ count: totalKeyResults }] = await keyResultsQuery;

    // Total actions
    let actionsQuery = db
      .select({ count: sql<number>`count(*)` })
      .from(actions)
      .innerJoin(keyResults, eq(actions.keyResultId, keyResults.id))
      .innerJoin(objectives, eq(keyResults.objectiveId, objectives.id));
    if (conditions.length > 0) {
      actionsQuery = actionsQuery.where(and(...conditions));
    }
    const [{ count: totalActions }] = await actionsQuery;

    // Average progress
    let progressQuery = db
      .select({ avg: sql<number>`avg(${objectives.progress})` })
      .from(objectives);
    if (conditions.length > 0) {
      progressQuery = progressQuery.where(and(...conditions));
    }
    const [{ avg: averageProgress }] = await progressQuery;

    // Status distribution
    let statusQuery = db
      .select({
        status: objectives.status,
        count: sql<number>`count(*)`
      })
      .from(objectives)
      .groupBy(objectives.status);
    if (conditions.length > 0) {
      statusQuery = statusQuery.where(and(...conditions));
    }
    const statusResults = await statusQuery;
    const statusDistribution = statusResults.reduce((acc, { status, count }) => {
      acc[status || 'Não Definido'] = count;
      return acc;
    }, {} as Record<string, number>);

    // Progress by service line
    let progressByServiceLineQuery = db
      .select({
        serviceLineName: serviceLines.name,
        progress: sql<number>`avg(${objectives.progress})`
      })
      .from(objectives)
      .innerJoin(serviceLines, eq(objectives.serviceLineId, serviceLines.id))
      .groupBy(serviceLines.name);
    if (conditions.length > 0) {
      progressByServiceLineQuery = progressByServiceLineQuery.where(and(...conditions));
    }
    const progressByServiceLine = await progressByServiceLineQuery;

    return {
      totalObjectives: totalObjectives || 0,
      totalKeyResults: totalKeyResults || 0,
      totalActions: totalActions || 0,
      averageProgress: Number(averageProgress) || 0,
      statusDistribution,
      progressByServiceLine: progressByServiceLine.map(p => ({
        serviceLineName: p.serviceLineName || '',
        progress: Number(p.progress) || 0
      }))
    };
  }
}

export const storage = new DatabaseStorage();
