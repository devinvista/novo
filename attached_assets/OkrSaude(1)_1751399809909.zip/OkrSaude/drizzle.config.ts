
import { defineConfig } from "drizzle-kit";

if (!process.env.SQL_SERVER_CONNECTION_STRING) {
  throw new Error("SQL_SERVER_CONNECTION_STRING must be set");
}

export default defineConfig({
  out: "./migrations",
  schema: "./shared/schema.ts",
  dialect: "mssql",
  dbCredentials: {
    url: process.env.SQL_SERVER_CONNECTION_STRING,
  },
});
