export const SERVICE_LINES = [
  { id: 1, name: 'Saúde Ocupacional', solution: 'Saúde' },
  { id: 2, name: 'Segurança do Trabalho', solution: 'Saúde' },
  { id: 3, name: 'Saúde Mental', solution: 'Saúde' },
  { id: 4, name: 'Educação Básica', solution: 'Educação' },
  { id: 5, name: 'Nutrição', solution: 'Saúde' },
  { id: 6, name: 'Odontologia', solution: 'Saúde' },
  { id: 7, name: 'Promoção da Saúde', solution: 'Saúde' },
  { id: 8, name: 'Atividade Física', solution: 'Saúde' },
];

export const REGIONS = [
  { id: 1, name: 'Norte', code: 'N' },
  { id: 2, name: 'Nordeste', code: 'NE' },
  { id: 3, name: 'Centro-Oeste', code: 'CO' },
  { id: 4, name: 'Sudeste', code: 'SE' },
  { id: 5, name: 'Sul', code: 'S' },
];

export const PERIODS = [
  { id: 1, name: 'T1 2025', year: 2025, quarter: 1 },
  { id: 2, name: 'T2 2025', year: 2025, quarter: 2 },
  { id: 3, name: 'T3 2025', year: 2025, quarter: 3 },
  { id: 4, name: 'T4 2025', year: 2025, quarter: 4 },
];
