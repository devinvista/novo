export interface DashboardMetrics {
  totalObjectives: number;
  totalKeyResults: number;
  totalActions: number;
  averageProgress: number;
  statusDistribution: Record<string, number>;
  progressByServiceLine: Array<{
    serviceLineName: string;
    progress: number;
  }>;
}

export interface FilterState {
  serviceLineId?: number;
  periodId?: number;
  regionId?: number;
  responsibleId?: string;
  status?: string;
}

export const STATUS_OPTIONS = [
  { value: 'Não Iniciado', label: 'Não Iniciado', color: 'bg-gray-100 text-gray-700' },
  { value: 'Em Andamento', label: 'Em Andamento', color: 'bg-blue-100 text-blue-700' },
  { value: 'Concluído', label: 'Concluído', color: 'bg-green-100 text-green-700' },
  { value: 'Atrasado', label: 'Atrasado', color: 'bg-red-100 text-red-700' },
  { value: 'Em Risco', label: 'Em Risco', color: 'bg-yellow-100 text-yellow-700' },
];

export const PRIORITY_OPTIONS = [
  { value: 'Alta', label: 'Alta', color: 'bg-red-100 text-red-700' },
  { value: 'Média', label: 'Média', color: 'bg-yellow-100 text-yellow-700' },
  { value: 'Baixa', label: 'Baixa', color: 'bg-green-100 text-green-700' },
];
