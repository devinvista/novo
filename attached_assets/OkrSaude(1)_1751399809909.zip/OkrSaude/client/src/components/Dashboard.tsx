import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Target, 
  Key, 
  CheckSquare, 
  TrendingUp, 
  Plus,
  Eye,
  Edit,
  Trash2,
  AlertTriangle,
  Trophy,
  Download
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { DashboardMetrics, FilterState, STATUS_OPTIONS } from "@/types";

interface DashboardProps {
  filters: FilterState;
}

export default function Dashboard({ filters }: DashboardProps) {
  const { data: metrics, isLoading: metricsLoading } = useQuery<DashboardMetrics>({
    queryKey: ['/api/dashboard/metrics', filters],
  });

  const { data: objectives = [], isLoading: objectivesLoading } = useQuery({
    queryKey: ['/api/objectives', filters],
  });

  const getStatusColor = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(opt => opt.value === status);
    return statusOption?.color || 'bg-gray-100 text-gray-700';
  };

  const formatProgress = (progress: number | string) => {
    const numProgress = typeof progress === 'string' ? parseFloat(progress) : progress;
    return isNaN(numProgress) ? 0 : Math.round(numProgress);
  };

  if (metricsLoading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header do Dashboard */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 flex items-center">
            <TrendingUp className="text-primary mr-3" size={32} />
            Dashboard
          </h2>
          <p className="text-gray-600 mt-1">Visão geral do progresso dos OKRs</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button variant="outline" className="flex items-center">
            <Download className="mr-2" size={16} />
            Exportar
          </Button>
          <Button className="bg-primary hover:bg-primary/90 flex items-center">
            <Plus className="mr-2" size={16} />
            Novo Objetivo
          </Button>
        </div>
      </div>

      {/* Cards de Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="card-hover transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Objetivos</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {metrics?.totalObjectives || 0}
                </p>
                <p className="text-sm text-gray-500 mt-1">Total de objetivos</p>
              </div>
              <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                <Target className="text-primary" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resultados-Chave</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {metrics?.totalKeyResults || 0}
                </p>
                <p className="text-sm text-gray-500 mt-1">Total de KRs</p>
              </div>
              <div className="w-12 h-12 bg-secondary bg-opacity-10 rounded-lg flex items-center justify-center">
                <Key className="text-secondary" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Ações</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">
                  {metrics?.totalActions || 0}
                </p>
                <p className="text-sm text-gray-500 mt-1">Total de ações</p>
              </div>
              <div className="w-12 h-12 bg-warning bg-opacity-10 rounded-lg flex items-center justify-center">
                <CheckSquare className="text-warning" size={24} />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover transition-all">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Progresso Médio</p>
                <p className="text-3xl font-bold text-primary mt-1">
                  {formatProgress(metrics?.averageProgress || 0)}%
                </p>
                <p className="text-sm text-gray-500 mt-1">Média geral</p>
              </div>
              <div className="w-12 h-12 bg-success bg-opacity-10 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-success" size={24} />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={formatProgress(metrics?.averageProgress || 0)} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos e Tabelas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Status dos Objetivos */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Status dos Objetivos
              <Target className="text-gray-400" size={20} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(metrics?.statusDistribution || {}).map(([status, count]) => (
                <div key={status} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`w-4 h-4 rounded mr-3 ${getStatusColor(status).split(' ')[0]}`}></div>
                    <span className="text-sm text-gray-600">{status}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-900">{count}</span>
                    <span className="text-xs text-gray-500">
                      ({metrics?.totalObjectives ? Math.round((count / metrics.totalObjectives) * 100) : 0}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Progresso por Linha de Serviço */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Progresso por Linha de Serviço
              <TrendingUp className="text-gray-400" size={20} />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics?.progressByServiceLine?.map((line, index) => (
                <div key={index}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">{line.serviceLineName}</span>
                    <span className="text-sm font-bold text-primary">{formatProgress(line.progress)}%</span>
                  </div>
                  <Progress value={formatProgress(line.progress)} className="h-2" />
                </div>
              )) || (
                <p className="text-sm text-gray-500 text-center py-4">
                  Nenhum dado disponível
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lista de Objetivos Recentes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Objetivos em Destaque
            <Button variant="link" className="text-primary">
              Ver todos
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {objectivesLoading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : objectives.length === 0 ? (
            <div className="text-center py-8">
              <Target className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-lg font-medium text-gray-900 mb-2">Nenhum objetivo encontrado</p>
              <p className="text-gray-500 mb-4">Comece criando seu primeiro objetivo estratégico.</p>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2" size={16} />
                Criar Objetivo
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Objetivo
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Progresso
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {objectives.slice(0, 5).map((objective: any) => (
                    <tr key={objective.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-2 h-8 bg-primary rounded-l mr-3"></div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">{objective.title}</p>
                            <p className="text-sm text-gray-500">
                              {objective.period?.name || 'Sem período'}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Badge className={`${getStatusColor(objective.status || 'Não Iniciado')} border-0`}>
                          {objective.status || 'Não Iniciado'}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <div className="w-16 bg-gray-200 rounded-full h-2 mr-3">
                            <div 
                              className="progress-bar-bg h-2 rounded-full" 
                              style={{ width: `${formatProgress(objective.progress || 0)}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {formatProgress(objective.progress || 0)}%
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-primary">
                            <Eye size={16} />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-secondary">
                            <Edit size={16} />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-error">
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
