import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  BarChart3, 
  Target, 
  Key, 
  CheckSquare, 
  FileText, 
  Filter,
  X,
  Briefcase,
  UserCheck,
  Brain,
  GraduationCap,
  Apple,
  Stethoscope
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { FilterState } from "@/types";

interface SidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
}

export default function Sidebar({ filters, onFiltersChange }: SidebarProps) {
  const [location] = useLocation();

  const { data: serviceLines = [] } = useQuery({
    queryKey: ['/api/service-lines'],
  });

  const { data: periods = [] } = useQuery({
    queryKey: ['/api/periods'],
  });

  const { data: regions = [] } = useQuery({
    queryKey: ['/api/regions'],
  });

  const navigationItems = [
    { href: "/", icon: BarChart3, label: "Dashboard" },
    { href: "/objetivos", icon: Target, label: "Objetivos" },
    { href: "/resultados-chave", icon: Key, label: "Resultados-Chave" },
    { href: "/acoes", icon: CheckSquare, label: "Ações" },
    { href: "/relatorios", icon: FileText, label: "Relatórios" },
  ];

  const serviceLineIcons = {
    'Saúde Ocupacional': Briefcase,
    'Segurança do Trabalho': UserCheck,
    'Saúde Mental': Brain,
    'Educação Básica': GraduationCap,
    'Nutrição': Apple,
    'Odontologia': Stethoscope,
  };

  const clearFilters = () => {
    onFiltersChange({});
  };

  return (
    <aside className="w-80 bg-white shadow-material-lg border-r border-gray-200 overflow-y-auto fixed left-0 top-16 bottom-0 z-40">
      <div className="p-6">
        {/* Filtros */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Filter className="text-primary mr-2" size={20} />
            Filtros
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Linha de Serviço
              </label>
              <Select
                value={filters.serviceLineId?.toString() || ""}
                onValueChange={(value) => 
                  onFiltersChange({ 
                    ...filters, 
                    serviceLineId: value ? parseInt(value) : undefined 
                  })
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Selecionar linha" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas</SelectItem>
                  {serviceLines.map((line: any) => (
                    <SelectItem key={line.id} value={line.id.toString()}>
                      {line.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Período
              </label>
              <Select
                value={filters.periodId?.toString() || ""}
                onValueChange={(value) => 
                  onFiltersChange({ 
                    ...filters, 
                    periodId: value ? parseInt(value) : undefined 
                  })
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Selecionar período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  {periods.map((period: any) => (
                    <SelectItem key={period.id} value={period.id.toString()}>
                      {period.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status
              </label>
              <Select
                value={filters.status || ""}
                onValueChange={(value) => 
                  onFiltersChange({ 
                    ...filters, 
                    status: value || undefined 
                  })
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos</SelectItem>
                  <SelectItem value="Não Iniciado">Não Iniciado</SelectItem>
                  <SelectItem value="Em Andamento">Em Andamento</SelectItem>
                  <SelectItem value="Concluído">Concluído</SelectItem>
                  <SelectItem value="Atrasado">Atrasado</SelectItem>
                  <SelectItem value="Em Risco">Em Risco</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button
              variant="outline"
              onClick={clearFilters}
              className="w-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors text-sm"
            >
              <X className="mr-2" size={16} />
              Limpar Filtros
            </Button>
          </div>
        </div>

        {/* Navegação */}
        <nav className="space-y-2">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Navegação</h3>
          
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || 
              (item.href !== "/" && location.startsWith(item.href));
            
            return (
              <Link key={item.href} href={item.href}>
                <a className={`nav-item flex items-center px-4 py-3 rounded-lg font-medium transition-all ${
                  isActive 
                    ? 'text-primary bg-primary bg-opacity-10' 
                    : 'text-gray-700 hover:text-primary'
                }`}>
                  <Icon className="mr-3" size={18} />
                  {item.label}
                </a>
              </Link>
            );
          })}
        </nav>
        
        {/* Linhas de Serviço */}
        <div className="mt-8">
          <h4 className="text-md font-medium text-gray-700 mb-3">Linhas de Serviço</h4>
          <div className="space-y-1 text-sm">
            {serviceLines.slice(0, 6).map((line: any) => {
              const IconComponent = serviceLineIcons[line.name as keyof typeof serviceLineIcons] || Briefcase;
              return (
                <button
                  key={line.id}
                  onClick={() => onFiltersChange({ ...filters, serviceLineId: line.id })}
                  className="w-full text-left px-3 py-2 text-gray-600 hover:text-primary hover:bg-primary hover:bg-opacity-5 rounded transition-all flex items-center"
                >
                  <IconComponent className="mr-2" size={16} />
                  {line.name}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </aside>
  );
}
