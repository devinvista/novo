import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Calendar, MapPin, User, Building, Target, Key, CheckSquare } from "lucide-react";
import { STATUS_OPTIONS } from "@/types";

interface ObjectiveDetailsProps {
  objective: any;
  isOpen: boolean;
  onClose: () => void;
}

export default function ObjectiveDetails({ objective, isOpen, onClose }: ObjectiveDetailsProps) {
  const { data: keyResults = [] } = useQuery({
    queryKey: ['/api/key-results', { objectiveId: objective?.id }],
    enabled: !!objective?.id,
  });

  const { data: serviceLines = [] } = useQuery({
    queryKey: ['/api/service-lines'],
  });

  const { data: regions = [] } = useQuery({
    queryKey: ['/api/regions'],
  });

  const { data: periods = [] } = useQuery({
    queryKey: ['/api/periods'],
  });

  if (!objective) return null;

  const getStatusColor = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(opt => opt.value === status);
    return statusOption?.color || 'bg-gray-100 text-gray-700';
  };

  const formatProgress = (progress: number | string) => {
    const numProgress = typeof progress === 'string' ? parseFloat(progress) : progress;
    return isNaN(numProgress) ? 0 : Math.round(numProgress);
  };

  const formatDate = (date: string) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const serviceLine = serviceLines.find((sl: any) => sl.id === objective.serviceLineId);
  const region = regions.find((r: any) => r.id === objective.regionId);
  const period = periods.find((p: any) => p.id === objective.periodId);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Target className="mr-2 text-primary" size={24} />
            Detalhes do Objetivo
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header Information */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {objective.title}
                  </h3>
                  {objective.description && (
                    <p className="text-gray-600 leading-relaxed">
                      {objective.description}
                    </p>
                  )}
                </div>
                <div className="ml-4 text-right">
                  <Badge className={`${getStatusColor(objective.status || 'Não Iniciado')} border-0 mb-2`}>
                    {objective.status || 'Não Iniciado'}
                  </Badge>
                  <div className="text-sm text-gray-500">
                    Progresso: {formatProgress(objective.progress || 0)}%
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <Progress value={formatProgress(objective.progress || 0)} className="h-3" />
              </div>
            </CardHeader>
          </Card>

          {/* Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Informações Gerais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Building className="text-gray-400" size={18} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Linha de Serviço</p>
                    <p className="text-sm text-gray-600">{serviceLine?.name || '-'}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Calendar className="text-gray-400" size={18} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Período</p>
                    <p className="text-sm text-gray-600">{period?.name || '-'}</p>
                  </div>
                </div>

                {region && (
                  <div className="flex items-center space-x-3">
                    <MapPin className="text-gray-400" size={18} />
                    <div>
                      <p className="text-sm font-medium text-gray-900">Região</p>
                      <p className="text-sm text-gray-600">{region.name}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Cronograma</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Calendar className="text-gray-400" size={18} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Data de Início</p>
                    <p className="text-sm text-gray-600">{formatDate(objective.startDate)}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Calendar className="text-gray-400" size={18} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Data de Fim</p>
                    <p className="text-sm text-gray-600">{formatDate(objective.endDate)}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Calendar className="text-gray-400" size={18} />
                  <div>
                    <p className="text-sm font-medium text-gray-900">Criado em</p>
                    <p className="text-sm text-gray-600">
                      {objective.createdAt ? formatDate(objective.createdAt) : '-'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Separator />

          {/* Key Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Key className="mr-2 text-secondary" size={20} />
                Resultados-Chave ({keyResults.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {keyResults.length === 0 ? (
                <div className="text-center py-8">
                  <Key className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <p className="text-lg font-medium text-gray-900 mb-2">
                    Nenhum resultado-chave cadastrado
                  </p>
                  <p className="text-gray-500">
                    Adicione resultados-chave para acompanhar o progresso deste objetivo.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {keyResults.map((kr: any) => (
                    <div key={kr.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{kr.title}</h4>
                          {kr.description && (
                            <p className="text-sm text-gray-600 mb-2">{kr.description}</p>
                          )}
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            {kr.targetValue && (
                              <span>Meta: {kr.targetValue} {kr.unit}</span>
                            )}
                            {kr.currentValue && (
                              <span>Atual: {kr.currentValue} {kr.unit}</span>
                            )}
                          </div>
                        </div>
                        <div className="ml-4 text-right">
                          <Badge className={`${getStatusColor(kr.status || 'Não Iniciado')} border-0 mb-2`}>
                            {kr.status || 'Não Iniciado'}
                          </Badge>
                          <div className="text-sm text-gray-500">
                            {formatProgress(kr.progress || 0)}%
                          </div>
                        </div>
                      </div>
                      <div className="mt-3">
                        <Progress value={formatProgress(kr.progress || 0)} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
