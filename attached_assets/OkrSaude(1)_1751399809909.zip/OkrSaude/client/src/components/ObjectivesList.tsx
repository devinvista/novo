import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Edit, Trash2, Target, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { FilterState, STATUS_OPTIONS } from "@/types";
import CreateObjectiveDialog from "./CreateObjectiveDialog";
import ObjectiveDetails from "./ObjectiveDetails";

interface ObjectivesListProps {
  filters: FilterState;
}

export default function ObjectivesList({ filters }: ObjectivesListProps) {
  const [selectedObjective, setSelectedObjective] = useState<any>(null);
  const [editingObjective, setEditingObjective] = useState<any>(null);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: objectives = [], isLoading } = useQuery({
    queryKey: ['/api/objectives', filters],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  const { data: serviceLines = [] } = useQuery({
    queryKey: ['/api/service-lines'],
  });

  const { data: periods = [] } = useQuery({
    queryKey: ['/api/periods'],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/objectives/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/objectives'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      toast({
        title: "Sucesso",
        description: "Objetivo excluído com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao excluir objetivo. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(opt => opt.value === status);
    return statusOption?.color || 'bg-gray-100 text-gray-700';
  };

  const formatProgress = (progress: number | string) => {
    const numProgress = typeof progress === 'string' ? parseFloat(progress) : progress;
    return isNaN(numProgress) ? 0 : Math.round(numProgress);
  };

  const handleView = (objective: any) => {
    setSelectedObjective(objective);
    setIsDetailsOpen(true);
  };

  const handleEdit = (objective: any) => {
    setEditingObjective(objective);
    setIsCreateDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Tem certeza que deseja excluir este objetivo?")) {
      deleteMutation.mutate(id);
    }
  };

  const handleCreateSuccess = () => {
    setIsCreateDialogOpen(false);
    setEditingObjective(null);
  };

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-16 bg-gray-200 rounded"></div>
        ))}
      </div>
    );
  }

  if (objectives.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-12">
          <Target className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-lg font-medium text-gray-900 mb-2">
            Nenhum objetivo encontrado
          </p>
          <p className="text-gray-500 mb-4">
            {Object.keys(filters).length > 0 
              ? "Tente ajustar os filtros ou criar um novo objetivo."
              : "Comece criando seu primeiro objetivo estratégico."
            }
          </p>
          <Button 
            onClick={() => setIsCreateDialogOpen(true)}
            className="bg-primary hover:bg-primary/90"
          >
            <Plus className="mr-2" size={16} />
            Criar Objetivo
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Lista de Objetivos
            <span className="text-sm font-normal text-gray-500">
              {objectives.length} objetivos encontrados
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Objetivo
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Linha de Serviço
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Período
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progresso
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {objectives.map((objective: any) => (
                  <tr key={objective.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="w-2 h-8 bg-primary rounded-l mr-3"></div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {objective.title}
                          </p>
                          {objective.description && (
                            <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                              {objective.description.length > 100 
                                ? `${objective.description.substring(0, 100)}...`
                                : objective.description
                              }
                            </p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">
                        {serviceLines.find((sl: any) => sl.id === objective.serviceLineId)?.name || '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-gray-900">
                        {periods.find((p: any) => p.id === objective.periodId)?.name || '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={`${getStatusColor(objective.status || 'Não Iniciado')} border-0`}>
                        {objective.status || 'Não Iniciado'}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-200 rounded-full h-2 mr-3">
                          <div 
                            className="progress-bar-bg h-2 rounded-full" 
                            style={{ width: `${formatProgress(objective.progress || 0)}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900">
                          {formatProgress(objective.progress || 0)}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-primary"
                          onClick={() => handleView(objective)}
                        >
                          <Eye size={16} />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-secondary"
                          onClick={() => handleEdit(objective)}
                        >
                          <Edit size={16} />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-gray-400 hover:text-error"
                          onClick={() => handleDelete(objective.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <CreateObjectiveDialog
        isOpen={isCreateDialogOpen}
        onClose={() => {
          setIsCreateDialogOpen(false);
          setEditingObjective(null);
        }}
        objective={editingObjective}
        onSuccess={handleCreateSuccess}
      />

      <ObjectiveDetails
        objective={selectedObjective}
        isOpen={isDetailsOpen}
        onClose={() => {
          setIsDetailsOpen(false);
          setSelectedObjective(null);
        }}
      />
    </>
  );
}
