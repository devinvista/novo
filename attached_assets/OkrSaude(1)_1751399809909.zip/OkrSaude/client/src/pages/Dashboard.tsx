import { useState } from "react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import Dashboard from "@/components/Dashboard";
import { FilterState } from "@/types";

export default function DashboardPage() {
  const [filters, setFilters] = useState<FilterState>({});

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex pt-16">
        <Sidebar filters={filters} onFiltersChange={setFilters} />
        <main className="flex-1 ml-80 overflow-y-auto">
          <Dashboard filters={filters} />
        </main>
      </div>
    </div>
  );
}
