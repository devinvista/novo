import { Target, BarChart3, Users, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-secondary/5">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Target className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Sistema de Gestão de OKRs</h1>
                <p className="text-sm text-gray-600">SESI - Saúde e Educação</p>
              </div>
            </div>
            <Button onClick={handleLogin} className="bg-primary hover:bg-primary/90">
              Entrar
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Gerencie seus <span className="text-primary">OKRs</span><br />
            com inteligência e eficiência
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Plataforma completa para acompanhamento de objetivos estratégicos, 
            resultados-chave e ações em organizações de saúde e educação.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleLogin} 
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-lg px-8 py-4"
            >
              Começar Agora
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="text-lg px-8 py-4 border-2"
            >
              Saiba Mais
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Funcionalidades Principais
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Tudo que você precisa para gerenciar OKRs de forma eficiente e transparente
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="text-primary" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Gestão Hierárquica
                </h4>
                <p className="text-gray-600">
                  Organize objetivos, resultados-chave e ações em uma estrutura clara e hierárquica
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="text-secondary" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Dashboard Intuitivo
                </h4>
                <p className="text-gray-600">
                  Visualize o progresso em tempo real com gráficos e métricas personalizadas
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="text-success" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Colaboração
                </h4>
                <p className="text-gray-600">
                  Trabalhe em equipe com atribuição de responsáveis e acompanhamento compartilhado
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-warning/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-warning" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Checkpoints Automáticos
                </h4>
                <p className="text-gray-600">
                  Sistema automatizado de verificação de progresso e alertas proativos
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <BarChart3 className="text-purple-600" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Relatórios Avançados
                </h4>
                <p className="text-gray-600">
                  Exporte relatórios detalhados em Excel e PowerPoint para apresentações
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="text-indigo-600" size={32} />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">
                  Filtros Dinâmicos
                </h4>
                <p className="text-gray-600">
                  Filtre por linha de serviço, período, região e responsável para análises precisas
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl font-bold mb-4">
            Pronto para transformar sua gestão de OKRs?
          </h3>
          <p className="text-xl mb-8 opacity-90">
            Comece agora mesmo e veja como nossa plataforma pode impulsionar seus resultados
          </p>
          <Button 
            onClick={handleLogin}
            size="lg" 
            variant="secondary"
            className="text-lg px-8 py-4 bg-white text-primary hover:bg-gray-100"
          >
            Acessar Sistema
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Target className="text-white" size={18} />
              </div>
              <p className="text-sm">© 2025 SESI - Sistema de Gestão de OKRs</p>
            </div>
            <p className="text-sm text-gray-400">
              Saúde e Educação em foco
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
