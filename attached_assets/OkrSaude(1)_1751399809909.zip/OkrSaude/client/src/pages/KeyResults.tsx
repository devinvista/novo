import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Eye, Edit, Trash2, Key, Target } from "lucide-react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { FilterState, STATUS_OPTIONS } from "@/types";

const keyResultSchema = z.object({
  title: z.string().min(1, "Título é obrigatório"),
  description: z.string().optional(),
  objectiveId: z.number().min(1, "Objetivo é obrigatório"),
  category: z.string().optional(),
  targetValue: z.string().optional(),
  currentValue: z.string().optional(),
  unit: z.string().optional(),
  frequency: z.string().default("Mensal"),
  responsibleId: z.string().optional(),
  status: z.string().default("Não Iniciado"),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

type KeyResultFormData = z.infer<typeof keyResultSchema>;

export default function KeyResults() {
  const [filters, setFilters] = useState<FilterState>({});
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingKeyResult, setEditingKeyResult] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: keyResults = [], isLoading } = useQuery({
    queryKey: ['/api/key-results', filters],
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  const { data: objectives = [] } = useQuery({
    queryKey: ['/api/objectives'],
  });

  const form = useForm<KeyResultFormData>({
    resolver: zodResolver(keyResultSchema),
    defaultValues: {
      title: "",
      description: "",
      status: "Não Iniciado",
      frequency: "Mensal",
      currentValue: "0",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: KeyResultFormData) => {
      const payload = {
        ...data,
        targetValue: data.targetValue ? parseFloat(data.targetValue) : undefined,
        currentValue: data.currentValue ? parseFloat(data.currentValue) : 0,
      };
      await apiRequest("POST", "/api/key-results", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/key-results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Resultado-chave criado com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao criar resultado-chave. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<KeyResultFormData> }) => {
      const payload = {
        ...data,
        targetValue: data.targetValue ? parseFloat(data.targetValue as string) : undefined,
        currentValue: data.currentValue ? parseFloat(data.currentValue as string) : undefined,
      };
      await apiRequest("PUT", `/api/key-results/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/key-results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      setEditingKeyResult(null);
      form.reset();
      toast({
        title: "Sucesso",
        description: "Resultado-chave atualizado com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao atualizar resultado-chave. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/key-results/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/key-results'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/metrics'] });
      toast({
        title: "Sucesso",
        description: "Resultado-chave excluído com sucesso!",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Não autorizado",
          description: "Você foi desconectado. Redirecionando...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao excluir resultado-chave. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: KeyResultFormData) => {
    if (editingKeyResult) {
      updateMutation.mutate({ id: editingKeyResult.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleEdit = (keyResult: any) => {
    setEditingKeyResult(keyResult);
    form.reset({
      title: keyResult.title,
      description: keyResult.description || "",
      objectiveId: keyResult.objectiveId,
      category: keyResult.category || "",
      targetValue: keyResult.targetValue?.toString() || "",
      currentValue: keyResult.currentValue?.toString() || "0",
      unit: keyResult.unit || "",
      frequency: keyResult.frequency || "Mensal",
      responsibleId: keyResult.responsibleId || "",
      status: keyResult.status || "Não Iniciado",
      startDate: keyResult.startDate || "",
      endDate: keyResult.endDate || "",
    });
    setIsCreateDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Tem certeza que deseja excluir este resultado-chave?")) {
      deleteMutation.mutate(id);
    }
  };

  const resetForm = () => {
    setEditingKeyResult(null);
    form.reset({
      title: "",
      description: "",
      status: "Não Iniciado",
      frequency: "Mensal",
      currentValue: "0",
    });
  };

  const getStatusColor = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(opt => opt.value === status);
    return statusOption?.color || 'bg-gray-100 text-gray-700';
  };

  const formatProgress = (progress: number | string) => {
    const numProgress = typeof progress === 'string' ? parseFloat(progress) : progress;
    return isNaN(numProgress) ? 0 : Math.round(numProgress);
  };

  const calculateProgress = (current: number | string, target: number | string) => {
    const currentNum = typeof current === 'string' ? parseFloat(current) : current;
    const targetNum = typeof target === 'string' ? parseFloat(target) : target;
    
    if (!targetNum || targetNum === 0) return 0;
    return Math.min(Math.round((currentNum / targetNum) * 100), 100);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex pt-16">
        <Sidebar filters={filters} onFiltersChange={setFilters} />
        <main className="flex-1 ml-80 overflow-y-auto">
          <div className="p-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 flex items-center">
                  <Key className="text-secondary mr-3" size={32} />
                  Resultados-Chave
                </h2>
                <p className="text-gray-600 mt-1">Gerencie os resultados-chave dos seus objetivos</p>
              </div>

              <Dialog open={isCreateDialogOpen} onOpenChange={(open) => {
                setIsCreateDialogOpen(open);
                if (!open) resetForm();
              }}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary hover:bg-secondary/90">
                    <Plus className="mr-2" size={16} />
                    Novo Resultado-Chave
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>
                      {editingKeyResult ? "Editar Resultado-Chave" : "Novo Resultado-Chave"}
                    </DialogTitle>
                  </DialogHeader>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Título *</FormLabel>
                            <FormControl>
                              <Input placeholder="Digite o título do resultado-chave" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Descrição</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Descreva o resultado-chave..." 
                                className="min-h-[100px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="objectiveId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Objetivo *</FormLabel>
                            <Select
                              value={field.value?.toString() || ""}
                              onValueChange={(value) => field.onChange(parseInt(value))}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecionar objetivo" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {objectives.map((obj: any) => (
                                  <SelectItem key={obj.id} value={obj.id.toString()}>
                                    {obj.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Categoria</FormLabel>
                              <FormControl>
                                <Input placeholder="Ex: Faturamento, Atendimento" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="frequency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Frequência</FormLabel>
                              <Select value={field.value} onValueChange={field.onChange}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="Semanal">Semanal</SelectItem>
                                  <SelectItem value="Mensal">Mensal</SelectItem>
                                  <SelectItem value="Trimestral">Trimestral</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <FormField
                          control={form.control}
                          name="targetValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Meta</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  step="0.01"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="currentValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Valor Atual</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="0" 
                                  step="0.01"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="unit"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Unidade</FormLabel>
                              <FormControl>
                                <Input placeholder="R$, %, unidades" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {STATUS_OPTIONS.map((status) => (
                                  <SelectItem key={status.value} value={status.value}>
                                    {status.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="startDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Data de Início</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="endDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Data de Fim</FormLabel>
                              <FormControl>
                                <Input type="date" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="flex justify-end space-x-2 pt-4">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setIsCreateDialogOpen(false);
                            resetForm();
                          }}
                        >
                          Cancelar
                        </Button>
                        <Button
                          type="submit"
                          disabled={createMutation.isPending || updateMutation.isPending}
                          className="bg-secondary hover:bg-secondary/90"
                        >
                          {editingKeyResult ? "Atualizar" : "Criar"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Lista de Resultados-Chave
                  <span className="text-sm font-normal text-gray-500">
                    {keyResults.length} resultados-chave encontrados
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="animate-pulse space-y-4">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-16 bg-gray-200 rounded"></div>
                    ))}
                  </div>
                ) : keyResults.length === 0 ? (
                  <div className="text-center py-12">
                    <Key className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-lg font-medium text-gray-900 mb-2">
                      Nenhum resultado-chave encontrado
                    </p>
                    <p className="text-gray-500 mb-4">
                      {Object.keys(filters).length > 0 
                        ? "Tente ajustar os filtros ou criar um novo resultado-chave."
                        : "Comece criando seu primeiro resultado-chave."
                      }
                    </p>
                    <Button 
                      onClick={() => setIsCreateDialogOpen(true)}
                      className="bg-secondary hover:bg-secondary/90"
                    >
                      <Plus className="mr-2" size={16} />
                      Criar Resultado-Chave
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="min-w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Resultado-Chave
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Objetivo
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Meta / Atual
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Progresso
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Ações
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {keyResults.map((keyResult: any) => {
                          const objective = objectives.find((obj: any) => obj.id === keyResult.objectiveId);
                          const progress = calculateProgress(keyResult.currentValue || 0, keyResult.targetValue || 1);
                          
                          return (
                            <tr key={keyResult.id} className="hover:bg-gray-50 transition-colors">
                              <td className="px-6 py-4">
                                <div className="flex items-center">
                                  <div className="w-2 h-8 bg-secondary rounded-l mr-3"></div>
                                  <div>
                                    <p className="text-sm font-medium text-gray-900">
                                      {keyResult.title}
                                    </p>
                                    {keyResult.category && (
                                      <p className="text-sm text-gray-500">{keyResult.category}</p>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex items-center">
                                  <Target className="text-gray-400 mr-2" size={16} />
                                  <span className="text-sm text-gray-900">
                                    {objective?.title || '-'}
                                  </span>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm">
                                  <div className="font-medium text-gray-900">
                                    {keyResult.targetValue || '-'} {keyResult.unit}
                                  </div>
                                  <div className="text-gray-500">
                                    Atual: {keyResult.currentValue || 0} {keyResult.unit}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <Badge className={`${getStatusColor(keyResult.status || 'Não Iniciado')} border-0`}>
                                  {keyResult.status || 'Não Iniciado'}
                                </Badge>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex items-center">
                                  <div className="w-16 bg-gray-200 rounded-full h-2 mr-3">
                                    <div 
                                      className="bg-secondary h-2 rounded-full" 
                                      style={{ width: `${progress}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-medium text-gray-900">
                                    {progress}%
                                  </span>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex items-center space-x-2">
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-gray-400 hover:text-primary"
                                  >
                                    <Eye size={16} />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-gray-400 hover:text-secondary"
                                    onClick={() => handleEdit(keyResult)}
                                  >
                                    <Edit size={16} />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-gray-400 hover:text-error"
                                    onClick={() => handleDelete(keyResult.id)}
                                  >
                                    <Trash2 size={16} />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
