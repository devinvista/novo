import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileText, Download, Filter, Calendar, BarChart3, PieChart, TrendingUp } from "lucide-react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FilterState, STATUS_OPTIONS } from "@/types";

export default function Reports() {
  const [filters, setFilters] = useState<FilterState>({});
  const [reportType, setReportType] = useState<string>("geral");
  const [exportFormat, setExportFormat] = useState<string>("excel");

  const { data: metrics } = useQuery({
    queryKey: ['/api/dashboard/metrics', filters],
  });

  const { data: objectives = [] } = useQuery({
    queryKey: ['/api/objectives', filters],
  });

  const { data: keyResults = [] } = useQuery({
    queryKey: ['/api/key-results', filters],
  });

  const { data: actions = [] } = useQuery({
    queryKey: ['/api/actions', filters],
  });

  const { data: serviceLines = [] } = useQuery({
    queryKey: ['/api/service-lines'],
  });

  const { data: periods = [] } = useQuery({
    queryKey: ['/api/periods'],
  });

  const handleExport = () => {
    toast({
      title: "Exportação iniciada",
      description: `Relatório será exportado em formato ${exportFormat.toUpperCase()}`,
    });
    // TODO: Implement actual export functionality
  };

  const getStatusColor = (status: string) => {
    const statusOption = STATUS_OPTIONS.find(opt => opt.value === status);
    return statusOption?.color || 'bg-gray-100 text-gray-700';
  };

  const formatProgress = (progress: number | string) => {
    const numProgress = typeof progress === 'string' ? parseFloat(progress) : progress;
    return isNaN(numProgress) ? 0 : Math.round(numProgress);
  };

  const formatDate = (date: string) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const reportTypes = [
    { value: "geral", label: "Relatório Geral" },
    { value: "objetivos", label: "Objetivos Detalhados" },
    { value: "krs", label: "Resultados-Chave" },
    { value: "acoes", label: "Ações em Andamento" },
    { value: "progresso", label: "Progresso por Período" },
  ];

  const exportFormats = [
    { value: "excel", label: "Excel (.xlsx)" },
    { value: "powerpoint", label: "PowerPoint (.pptx)" },
    { value: "pdf", label: "PDF" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex pt-16">
        <Sidebar filters={filters} onFiltersChange={setFilters} />
        <main className="flex-1 ml-80 overflow-y-auto">
          <div className="p-8">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 flex items-center">
                  <FileText className="text-purple-600 mr-3" size={32} />
                  Relatórios
                </h2>
                <p className="text-gray-600 mt-1">Gere relatórios detalhados dos seus OKRs</p>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {reportTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={exportFormat} onValueChange={setExportFormat}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {exportFormats.map((format) => (
                        <SelectItem key={format.value} value={format.value}>
                          {format.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={handleExport} className="bg-purple-600 hover:bg-purple-700">
                  <Download className="mr-2" size={16} />
                  Exportar
                </Button>
              </div>
            </div>

            {/* Report Preview */}
            <div className="space-y-8">
              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Objetivos</p>
                        <p className="text-2xl font-bold text-gray-900">{metrics?.totalObjectives || 0}</p>
                      </div>
                      <BarChart3 className="text-primary" size={24} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Resultados-Chave</p>
                        <p className="text-2xl font-bold text-gray-900">{metrics?.totalKeyResults || 0}</p>
                      </div>
                      <PieChart className="text-secondary" size={24} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Ações</p>
                        <p className="text-2xl font-bold text-gray-900">{metrics?.totalActions || 0}</p>
                      </div>
                      <TrendingUp className="text-warning" size={24} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Progresso Médio</p>
                        <p className="text-2xl font-bold text-primary">
                          {formatProgress(metrics?.averageProgress || 0)}%
                        </p>
                      </div>
                      <div className="w-8 h-8 bg-success bg-opacity-10 rounded-full flex items-center justify-center">
                        <TrendingUp className="text-success" size={16} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Detailed Report Content */}
              {reportType === "geral" && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Status Distribution */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Distribuição por Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {Object.entries(metrics?.statusDistribution || {}).map(([status, count]) => (
                          <div key={status} className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className={`w-4 h-4 rounded mr-3 ${getStatusColor(status).split(' ')[0]}`}></div>
                              <span className="text-sm text-gray-700">{status}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <span className="text-sm font-medium text-gray-900">{count}</span>
                              <span className="text-xs text-gray-500">
                                ({metrics?.totalObjectives ? Math.round((count / metrics.totalObjectives) * 100) : 0}%)
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Progress by Service Line */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Progresso por Linha de Serviço</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {metrics?.progressByServiceLine?.map((line, index) => (
                          <div key={index}>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium text-gray-700">{line.serviceLineName}</span>
                              <span className="text-sm font-bold text-primary">{formatProgress(line.progress)}%</span>
                            </div>
                            <Progress value={formatProgress(line.progress)} className="h-2" />
                          </div>
                        )) || (
                          <p className="text-sm text-gray-500 text-center py-4">
                            Nenhum dado disponível
                          </p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {reportType === "objetivos" && (
                <Card>
                  <CardHeader>
                    <CardTitle>Objetivos Detalhados</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {objectives.length === 0 ? (
                      <p className="text-center py-8 text-gray-500">Nenhum objetivo encontrado</p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="min-w-full">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                Objetivo
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                Linha de Serviço
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                Status
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                Progresso
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                Prazo
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {objectives.map((objective: any) => (
                              <tr key={objective.id}>
                                <td className="px-6 py-4">
                                  <div>
                                    <p className="text-sm font-medium text-gray-900">{objective.title}</p>
                                    {objective.description && (
                                      <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                                        {objective.description}
                                      </p>
                                    )}
                                  </div>
                                </td>
                                <td className="px-6 py-4">
                                  <span className="text-sm text-gray-900">
                                    {serviceLines.find((sl: any) => sl.id === objective.serviceLineId)?.name || '-'}
                                  </span>
                                </td>
                                <td className="px-6 py-4">
                                  <Badge className={`${getStatusColor(objective.status || 'Não Iniciado')} border-0`}>
                                    {objective.status || 'Não Iniciado'}
                                  </Badge>
                                </td>
                                <td className="px-6 py-4">
                                  <div className="flex items-center">
                                    <div className="w-16 bg-gray-200 rounded-full h-2 mr-3">
                                      <div 
                                        className="progress-bar-bg h-2 rounded-full" 
                                        style={{ width: `${formatProgress(objective.progress || 0)}%` }}
                                      ></div>
                                    </div>
                                    <span className="text-sm font-medium text-gray-900">
                                      {formatProgress(objective.progress || 0)}%
                                    </span>
                                  </div>
                                </td>
                                <td className="px-6 py-4">
                                  <span className="text-sm text-gray-900">
                                    {formatDate(objective.endDate)}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Report Metadata */}
              <Card>
                <CardHeader>
                  <CardTitle>Informações do Relatório</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Data de Geração</p>
                      <p className="text-sm text-gray-900">{new Date().toLocaleDateString('pt-BR')}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Período de Análise</p>
                      <p className="text-sm text-gray-900">
                        {filters.periodId 
                          ? periods.find((p: any) => p.id === filters.periodId)?.name || 'Período específico'
                          : 'Todos os períodos'
                        }
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-600 mb-1">Filtros Aplicados</p>
                      <p className="text-sm text-gray-900">
                        {Object.keys(filters).length > 0 
                          ? `${Object.keys(filters).length} filtro(s) ativo(s)`
                          : 'Nenhum filtro aplicado'
                        }
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
