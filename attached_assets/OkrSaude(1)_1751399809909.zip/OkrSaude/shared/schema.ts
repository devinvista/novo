
import {
  varchar,
  text,
  timestamp,
  index,
  int,
  decimal,
  date,
  bit,
  uniqueIdentifier,
} from "drizzle-orm/mssql-core";
import { sqlServerTable } from "drizzle-orm/mssql-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";

// Session storage table - required for Replit Auth
export const sessions = sqlServerTable(
  "sessions",
  {
    sid: varchar("sid", { length: 255 }).primaryKey(),
    sess: text("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
);

// User storage table - required for Replit Auth
export const users = sqlServerTable("users", {
  id: varchar("id", { length: 255 }).primaryKey().notNull(),
  email: varchar("email", { length: 255 }),
  firstName: varchar("first_name", { length: 255 }),
  lastName: varchar("last_name", { length: 255 }),
  profileImageUrl: varchar("profile_image_url", { length: 500 }),
  role: varchar("role", { length: 50 }).default("user"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Service Lines (Linhas de Serviço)
export const serviceLines = sqlServerTable("service_lines", {
  id: int("id").primaryKey().identity(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  solution: varchar("solution", { length: 100 }), // "Saúde" or "Educação"
  active: bit("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Regions (Regiões)
export const regions = sqlServerTable("regions", {
  id: int("id").primaryKey().identity(),
  name: varchar("name", { length: 255 }).notNull(),
  code: varchar("code", { length: 50 }),
  active: bit("active").default(true),
});

// Periods (Períodos)
export const periods = sqlServerTable("periods", {
  id: int("id").primaryKey().identity(),
  name: varchar("name", { length: 100 }).notNull(), // T1 2025, T2 2025, etc.
  year: int("year").notNull(),
  quarter: int("quarter").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  active: bit("active").default(true),
});

// Objectives (Objetivos)
export const objectives = sqlServerTable("objectives", {
  id: int("id").primaryKey().identity(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  serviceLineId: int("service_line_id").references(() => serviceLines.id),
  regionId: int("region_id").references(() => regions.id),
  periodId: int("period_id").references(() => periods.id),
  responsibleId: varchar("responsible_id", { length: 255 }).references(() => users.id),
  status: varchar("status", { length: 50 }).default("Não Iniciado"),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0.00"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  createdBy: varchar("created_by", { length: 255 }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Key Results (Resultados-Chave)
export const keyResults = sqlServerTable("key_results", {
  id: int("id").primaryKey().identity(),
  objectiveId: int("objective_id").references(() => objectives.id),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  targetValue: decimal("target_value", { precision: 15, scale: 2 }),
  currentValue: decimal("current_value", { precision: 15, scale: 2 }).default("0.00"),
  unit: varchar("unit", { length: 50 }),
  frequency: varchar("frequency", { length: 50 }).default("Mensal"),
  responsibleId: varchar("responsible_id", { length: 255 }).references(() => users.id),
  status: varchar("status", { length: 50 }).default("Não Iniciado"),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0.00"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  createdBy: varchar("created_by", { length: 255 }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Actions (Ações)
export const actions = sqlServerTable("actions", {
  id: int("id").primaryKey().identity(),
  keyResultId: int("key_result_id").references(() => keyResults.id),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  responsibleId: varchar("responsible_id", { length: 255 }).references(() => users.id),
  status: varchar("status", { length: 50 }).default("Não Iniciado"),
  priority: varchar("priority", { length: 20 }).default("Média"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  completedAt: timestamp("completed_at"),
  comments: text("comments"),
  createdBy: varchar("created_by", { length: 255 }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Checkpoints for KRs (Checkpoints automáticos)
export const checkpoints = sqlServerTable("checkpoints", {
  id: int("id").primaryKey().identity(),
  keyResultId: int("key_result_id").references(() => keyResults.id),
  date: date("date").notNull(),
  targetValue: decimal("target_value", { precision: 15, scale: 2 }),
  actualValue: decimal("actual_value", { precision: 15, scale: 2 }),
  status: varchar("status", { length: 50 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Progress History (Histórico de progresso)
export const progressHistory = sqlServerTable("progress_history", {
  id: int("id").primaryKey().identity(),
  entityType: varchar("entity_type", { length: 50 }).notNull(),
  entityId: int("entity_id").notNull(),
  previousProgress: decimal("previous_progress", { precision: 5, scale: 2 }),
  newProgress: decimal("new_progress", { precision: 5, scale: 2 }),
  updatedBy: varchar("updated_by", { length: 255 }).references(() => users.id),
  updatedAt: timestamp("updated_at").defaultNow(),
  notes: text("notes"),
});

// Relations mantêm a mesma estrutura
export const usersRelations = relations(users, ({ many }) => ({
  objectives: many(objectives),
  keyResults: many(keyResults),
  actions: many(actions),
}));

export const serviceLinesRelations = relations(serviceLines, ({ many }) => ({
  objectives: many(objectives),
}));

export const regionsRelations = relations(regions, ({ many }) => ({
  objectives: many(objectives),
}));

export const periodsRelations = relations(periods, ({ many }) => ({
  objectives: many(objectives),
}));

export const objectivesRelations = relations(objectives, ({ one, many }) => ({
  serviceLine: one(serviceLines, {
    fields: [objectives.serviceLineId],
    references: [serviceLines.id],
  }),
  region: one(regions, {
    fields: [objectives.regionId],
    references: [regions.id],
  }),
  period: one(periods, {
    fields: [objectives.periodId],
    references: [periods.id],
  }),
  responsible: one(users, {
    fields: [objectives.responsibleId],
    references: [users.id],
  }),
  keyResults: many(keyResults),
}));

export const keyResultsRelations = relations(keyResults, ({ one, many }) => ({
  objective: one(objectives, {
    fields: [keyResults.objectiveId],
    references: [objectives.id],
  }),
  responsible: one(users, {
    fields: [keyResults.responsibleId],
    references: [users.id],
  }),
  actions: many(actions),
  checkpoints: many(checkpoints),
}));

export const actionsRelations = relations(actions, ({ one }) => ({
  keyResult: one(keyResults, {
    fields: [actions.keyResultId],
    references: [keyResults.id],
  }),
  responsible: one(users, {
    fields: [actions.responsibleId],
    references: [users.id],
  }),
}));

export const checkpointsRelations = relations(checkpoints, ({ one }) => ({
  keyResult: one(keyResults, {
    fields: [checkpoints.keyResultId],
    references: [keyResults.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export const insertServiceLineSchema = createInsertSchema(serviceLines);
export const insertRegionSchema = createInsertSchema(regions);
export const insertPeriodSchema = createInsertSchema(periods);
export const insertObjectiveSchema = createInsertSchema(objectives);
export const insertKeyResultSchema = createInsertSchema(keyResults);
export const insertActionSchema = createInsertSchema(actions);
export const insertCheckpointSchema = createInsertSchema(checkpoints);

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type ServiceLine = typeof serviceLines.$inferSelect;
export type Region = typeof regions.$inferSelect;
export type Period = typeof periods.$inferSelect;
export type Objective = typeof objectives.$inferSelect;
export type KeyResult = typeof keyResults.$inferSelect;
export type Action = typeof actions.$inferSelect;
export type Checkpoint = typeof checkpoints.$inferSelect;
export type ProgressHistory = typeof progressHistory.$inferSelect;

export type InsertServiceLine = typeof serviceLines.$inferInsert;
export type InsertRegion = typeof regions.$inferInsert;
export type InsertPeriod = typeof periods.$inferInsert;
export type InsertObjective = typeof objectives.$inferInsert;
export type InsertKeyResult = typeof keyResults.$inferInsert;
export type InsertAction = typeof actions.$inferInsert;
export type InsertCheckpoint = typeof checkpoints.$inferInsert;
