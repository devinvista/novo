# Sistema de Gestão de OKRs - SESI

## Overview

This is a full-stack web application for managing OKRs (Objectives and Key Results) designed specifically for SESI's health and education solutions. The system allows organizations to track strategic objectives, key results, and actions across different service lines, regions, and time periods.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend and backend concerns:

- **Frontend**: React-based SPA using Vite for development and build tooling
- **Backend**: Express.js server with RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with session management
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Forms**: React Hook Form with Zod validation
- **API Client**: Custom fetch-based client with TanStack Query

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ORM**: Drizzle ORM with PostgreSQL adapter
- **Authentication**: Passport.js with OpenID Connect strategy
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **API Structure**: RESTful endpoints organized by resource type

### Database Schema
The system manages several core entities:
- **Users**: Authentication and profile management
- **Service Lines**: Health and education service categories
- **Regions**: Geographic organizational units
- **Periods**: Time-based planning cycles
- **Objectives**: High-level strategic goals
- **Key Results**: Measurable outcomes tied to objectives
- **Actions**: Specific tasks that drive key results
- **Checkpoints**: Progress tracking milestones

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **API Requests**: Frontend makes authenticated requests to Express API endpoints
3. **Database Operations**: Drizzle ORM handles type-safe database queries
4. **State Management**: TanStack Query manages server state with caching and synchronization
5. **UI Updates**: React components re-render based on query state changes

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection pooling
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **react-hook-form**: Form state management
- **zod**: Runtime type validation

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Static type checking
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Production bundling

## Deployment Strategy

The application is configured for deployment on Replit's autoscale infrastructure:

- **Development**: `npm run dev` starts both frontend and backend in development mode
- **Build**: `npm run build` creates optimized production bundles
- **Production**: `npm run start` serves the built application
- **Database**: PostgreSQL provisioned via Replit's database service
- **Environment**: Configuration through environment variables (DATABASE_URL, SESSION_SECRET, etc.)

## Changelog

Changelog:
- June 25, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.